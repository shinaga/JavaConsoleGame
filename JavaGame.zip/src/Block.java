
public abstract class Block implements Aggressive{
	int y;
	protected int attack;
	char c;
}
class Normal extends Block{
	Normal(){
		attack=1;
		y=0;
		c='o';
	}

	@Override
	public void Aggro() {
		Player.hp-=attack;
	}
}
class Danger extends Block{
	Danger(){
		attack=3;
		y=0;
		c='@';
	}

	@Override
	public void Aggro() {
		Player.hp-=attack;
	}
}