public interface Aggressive {
	public abstract void Aggro();
}
