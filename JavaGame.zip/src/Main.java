import java.util.Random;
import javax.swing.*;
import java.awt.event.*;
public class Main {
       public static void clearScreen()  {
		   System.out.print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
           }
	

	public static void main(String[] args) throws InterruptedException{

		 final int n=29;// ���� ũ��� ���� 0~29, ���� 0~29 �� 30x30 ����� �ȴ�.
		   JFrame f = new JFrame();//Ű���� �Է��� �ޱ� ����
		      f.setSize(0,0);     
		      f.setLayout( null );

		      class key implements KeyListener{
		          
		          public void keyPressed(KeyEvent e) {
		           switch(e.getKeyCode()) {
		           case KeyEvent.VK_LEFT:
		        	   if(Player.x!=0&&Player.on==1)
		          	 Player.x--;
		          	 break;
		           case KeyEvent.VK_RIGHT:
		        	   if(Player.x!=n&&Player.on==1)
		        	   Player.x++;
			          	break;
		           }
		           
		          }

		          public void keyReleased(KeyEvent e){   
		          	
		              }          
		          public void keyTyped(KeyEvent e) { }            
		                      
		      }       
		      
		      f.setVisible(true);
		      f.addKeyListener(new key());
		      
      
		Random r=new Random();int []randomArray= new int[n+1];for(int i=0;i<=n;i++)randomArray[i]=0;
		int random;//���� �迭, ���� �� ���� 
		Block[][] blocks = new Block[n+1][n+1];//30x30 ���� ������
		int rotation=0;

		int dangerRotation=1;//3���� �ѹ� Danger��ü�� �����Բ� �����ؾ� ��.
		for(int i=0;i<=n;i++) {
			for(int j=0;j<=n;j++) {
				blocks[i][j]=null;
			}
		}
		//�迭 �ʱ�ȭ
	    int line=0;//���° blocks����
	    for(int i=10;i>=1;i--) {
	    clearScreen();
	    System.out.println("                                 �����̸�: ��� ���ض�! \n ���Ӽ���: ������ �������� ��� �¿� ����Ű�� ���ϸ� �˴ϴ�. ȭ�� �Ʒ��� HP�� ǥ�õǰ� o�� 1�� HP, @�� 3�� HP�� ���Դϴ�.\n                                "+i+"�ʵ� ������ ���۵˴ϴ�.\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
	    Thread.sleep(1000);
	    }
	    clearScreen();
	    Player.on=1;
		game:while(true) {
			for(int rand=0;rand<=2;rand++) {
	    	random=r.nextInt(n+1);
	    	if(randomArray[random]==1) {
	    		rand--;
	    		continue;
	    	}
	    	if(dangerRotation%3==0&&rand==0) {
	    		if(line>n) {
			        blocks[n][random]=new Danger();
			        randomArray[random]=1;
		    	}
		    	else{	
		        blocks[line][random]=new Danger();
		        randomArray[random]=1;
	    	    }
	    	}
	    	else {
	    	if(line>n) {
		        blocks[n][random]=new Normal();
		        randomArray[random]=1;
	    	}
	    	else{
	        blocks[line][random]=new Normal();
	        randomArray[random]=1;
	    	}
	    	}
	    }
			for(int i=n;i>=0;i--) {
		 for(int j=0;j<=n;j++) {
			   if(blocks[i][j]!=null) {
				 if(line>=n&&Player.x==j&&i==0) {}
				 else System.out.print(blocks[i][j].c);
				 blocks[i][j].y++;
				 if(blocks[i][j].y==n+1&&Player.x==j) {
					 blocks[i][j].Aggro();
					 if(Player.hp<=0) {
						 clearScreen();
						 System.out.print("                               ������ ���� �Ǿ����ϴ�.\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
						 break game;
					 }
				 }
			}
			 else if(blocks[i][j]==null){
				 if(line>=n&&Player.x==j&&i==0){}
				 else System.out.print(" ");
			 }
			 if(line>=n) {if(Player.x==j&&rotation==n) {
				 System.out.print("P");
			 }
			 }
			
		} 
		rotation++;
		 System.out.println("");
	}   
		if(line<n) {
			         for(int i=line;i<n;i++) {
			        	 if(i!=n-1)System.out.println();
			        	 else {
			        		 for(int j=0;j<Player.x;j++)System.out.print(" ");
			        		 System.out.print("P");
			        	 }
			         }
					 
		}
		if(line>=n)System.out.print("           HP: "+Player.hp);
		if(line<n)System.out.print("\n           HP: "+Player.hp);
		line++;for(int i=0;i<=n;i++)randomArray[i]=0;//�ʱ�ȭ
		 if(line>n) {
				for(int i=0;i<n;i++) {
					for(int j=0;j<=n;j++){
							blocks[i][j]=blocks[i+1][j];				

					}
				}
							for(int i=0;i<=n;i++)blocks[n][i]=null;
				}
		 rotation=0;
		 dangerRotation++;
		   Thread.sleep(80);
		   clearScreen();
		   }
	}
	}
	